<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    $color = array('white', 'green', 'red');


    echo "  <li>{$color[1]}</li>\n";
    echo "  <li>{$color[2]}</li>\n";
    echo "  <li>{$color[0]}</li>\n";

    ?>
</body>

</html>