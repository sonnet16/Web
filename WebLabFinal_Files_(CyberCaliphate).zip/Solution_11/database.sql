CREATE TABLE `employee` (
  `name` varchar(50) NOT NULL,
  `id` varchar(50) NOT NULL,
  `age` varchar(50) NOT NULL,
  `user` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
COMMIT;